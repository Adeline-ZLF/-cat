<?php
//引入连接数据库的代码
require './init.php';

//执行SQL语句
$sql = 'select `id`,`name`,`sex`,`phone`,`idnumber`, `position`,`salary` from `employee` order by `id` desc';
$stmt = $pdo->query($sql);  //返回PDOStatement对象
//处理结果集
$data = $stmt->fetchAll(PDO::FETCH_ASSOC);  //调用PDOStatement对象的fetchAll()方法处理结果集

//载入HTML模板
require './news.html';