
-- 为项目创建数据库
create database `qd239`;

-- 选择数据库
use `qd239`;

-- 创建新闻表
create table `news` (
  `id` int unsigned auto_increment primary key comment '新闻编号',
  `title` varchar(60) not null comment '新闻标题',
  `author` varchar(60) not null comment '发布者',
  `content` text not null comment '新闻内容',
  `addtime` timestamp default current_timestamp not null comment '发布时间'
)charset=utf8;

-- 插入测试数据

insert into `news` (`title`,`author`, `content`, `addtime`) values
('新闻标题1','张三', '新闻内容1', '2015-10-09 17:07:58'),
('新闻标题2','李四', '新闻内容2', '2015-10-11 12:06:56'),
('新闻标题3','张新科', '新闻内容3', '2015-11-11 10:05:08');

