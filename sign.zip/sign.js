<script>
window.onload = function () {
  var user = document.getElementById('inputEmail');
  var pass = document.getElementById('inputPassword');
  var oBtn = document.getElementById('btn');

  function functionName() {
    if ((user.value == "admin@qq.com") && (pass.value == "admin")) {
      alert("欢迎账号为" + user.value + "用户使用本系统！");
      window.open("192.168.1.131/grid/index.html");
    } else {
      alert("账号或密码输入错误，请重新输入！");
    }
  }
</script>
